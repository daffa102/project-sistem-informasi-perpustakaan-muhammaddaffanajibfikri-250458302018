# Play - Free Tailwind CSS Template for Startup, Apps and SaaS
#### Preview

 - [Demo](https://themewagon.github.io/play-tailwind/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/play-tailwind/)
 
 
## Getting Started

Clone from GitHub 
```
https://github.com/themewagon/play-tailwind.git
```

## Author

Design and code are completely written by TailGrids and UIdeck design and development team.  


## License

 - Design and Code is Copyright &copy; [TailGrids](https://tailgrids.com/)
 - Licensed under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)


